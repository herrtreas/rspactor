$:.unshift File.expand_path(File.dirname(__FILE__)) + "/lib"

require 'interop'
require 'inspection'
require 'runtime'
require 'command'

$coreInterop = RSpactor::Core::Interop.new